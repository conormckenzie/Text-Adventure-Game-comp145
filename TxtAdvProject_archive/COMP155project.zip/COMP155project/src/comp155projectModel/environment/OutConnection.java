/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp155projectModel.environment;

/**
 *
 * @author conor
 */
public class OutConnection {
    public int otherLocationIndex;
    public int outConnectionNumber;
    public String directionToOtherLocation;
}
